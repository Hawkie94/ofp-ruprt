*********************************************************************************************
****************************** DABOVAN� D�LOST�ELECK� PODPORA *******************************
******************************************* v1.0 ********************************************
*********************************************************************************************

1.)INFO
      
   - Autor            : F.D.O.F.
   - Verze hry        : 1.96 Resistance CZ
   - nazev skriptu    : Upraven� script (Bombing.sqs) od Celoushe a (Grid.sqs) od Je�ura
   - pot�ebn� scripty : Bombing.sqs, Grid.sqs, Description.ext!

=============================================================================================

2.)POPIS
Uk�zka dabovan� ��dosti o d�lost�eleckou podporu. Nejedn� se o d�lost�eleckou podporu (script by Celoush), ale o uk�zku dabovan� ��dosti.

============================================================================================

5.)KONTAKT

   - e-mail : fdof@centrum.cz
   - web    : http://www.rtcz.wz.cz


    
  