Meno: Alarm Skript v1.1
--------------------------------------------------
Autori: Munch Studios, Bobor SK, Brt, GAIA
--------------------------------------------------
Verzie:
1.0 >>> 1.1

Opravene >> Funkcnost samotneho skriptu (v 1.0 bola chyba s KnowsAbout)
Odstranene >> Alarm buda

--------------------------------------------------
Funkcia: Ak AI odhali danu osobu alebo mrtvolu, v zakladnej verzii skriptu sa po piatich sekundach spusti alarm
--------------------------------------------------
Pou�itie:
Subor "bsk_dead_target.pbo" prekopirujte do zlo�ky "addons" v zlozke vasho OFP.
Zlozku "alarm" skopirujte do zlozky vasej misie.

Skript spust�te pomocou tohoto prikazu:
[a,b] exec "alarm\control_alarm.sqs"

a - spinac, v ktorom AI moze odhalit mrtvolu alebo hraca (predmet "b")

b - meno osoby, ktoru AI v danom spinaci (predmet "a") hlada

Dalej musite zadat tieto udaje, ktore sa spustia este pred spusten�m celeho skriptu. Udaje:

Mrtvoly = []
alarm=false

Do skriptu "potom.sqs" zadajte, co chcete, aby sa stalo, ked sa ma spustit alarm (mozete tam dat napr. aby ten nalezca vykrikol "ALARM" alebo nieco podobne...)
-------------------------------------------------
UPOZORNENIE:
Tieto s�bory su volne siritelne s vynimkou zisku z predaja.
Ak chcete skript pouzit v nejakej svojej misii, nezabudnite dat autorov do credits!

Dotazy, otazky, bugy a ine posielajte na boborsk.ofp@inmail.sk .