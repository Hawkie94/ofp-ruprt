*********************************************************************************************
***************************************** KONTROLA ******************************************
***************************************** v0.9 BETA *****************************************
*********************************************************************************************

1.)INFO
      
   - Autor         : F.D.O.F.
   - Verze hry     : (V�rab�no v 1.96 Resistance), pot�ebn� verze (1.75 Resistance)
   - nazev skriptu : (Kontrola.sqs)

=============================================================================================

2.)POPIS
Skript na kontrolu pom�ru jednotek dvou stran ve sp�na�i. Jedn� se pouze o beta verzi. Napad� m� je�t� spousta v�c�, ale jsem l�n� je realizovat.

Skript se spou�t� -
[LIST,STRANA1,STRANA2,(�AS)] Exec "Kontrola.sqs"

LIST - n�zev sp�na�e ve kter�m se kontrola prov�d�.
STRANA1 - N�zev strany, kter� bude ve vyhodnocov�n� na prvn�m m�st� (West, Resistance...)
STRANA2 - N�zev strany, kter� bude ve vyhodnocov�n� na druh�m m�st� (West, Resistance...)
�AS - �as mezi dal�� kontrolou (nepovinn�)

============================================================================================

5.)KONTAKT

   - e-mail : fdof@centrum.cz
   - ICQ    : 291687574
   - web    : http://www.rtcz.wz.cz


    
  