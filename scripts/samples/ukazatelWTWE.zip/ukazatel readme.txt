
###########################################################################################################
EXAMPLE #######################################################################################
#############################################################################################

show -----> TitleRsc ["ukazatel","PLAIN"]
################# start [player] exec "health.sqs" (write in init.sqs or triger) !
###########################################################################################x




	class ukazatel
	{
		IDD = -1;
    		MovingEnable = 0;
    		duration = 99999;
		FadeIn = 0;
    		name = "[example] Ukazatel";
    		controls[] = {"RscGroupBox1","RscGroupBox101","RscGroupBox102","RscGroupBox103","RscGroupBox2","RscText"};


class RscGroupBox1 //(#######BACKGROUD OF HEALTBAR)
{
	type = 0;
	IDC = -1;
	style = 0;         //(#######STYLE OF HEALTBARR - SET 0(A HEALHTBAR) OR 128(B HEALTHBAR HUD BORDER)
	x = 0.297000;
	y = 0.039000;
	w = 0.405;
	h = 0.027;
	text = "";
	ColorBackground[] = {0,0,0,0.5}; //(#######COLOR OF BACKGROUND (Red,Greed,Blue,A)
	ColorText[] = {0,0,0,0};
	font = "tahomaB24";
	SizeEx = 0.020000;
		};

	



    		
	class RscGroupBox2        //(#######LINE OF HEALTHBAR)
	type = 0;
	IDC = -1;
	style = 0;    //(#######STYLE OF HEALTHBAR - SET 0(A HEALHTBAR) OR 128(B HEALTHBAR HUD BORDER)
	x = 0.3000;
	y = 0.04000;
	w = line/10; // ##########STATUS OF HEALT BAR - LINE = 4 (FULL HEALTH)
	h = 0.025;
	text = "";
	ColorBackground[] = {0,0.8,0,0.2};  //(#######COLOR OF HEALTHBAR (Red={0.8,0,0,0.2};GRAY{1,1,1,0.5})
	ColorText[] = {0,0,0,0};
	font = "tahomaB24";
	SizeEx = 0.020000;
		};

	class RscText
{
	type = 0;
	IDC = -1;
	style = 2 + 16 + 512;
	x = 0.240000;
	y = 0.040000;
	w = 0.15;
	h = 0.03;
	text = "Player";   //(####### NAME OF PLAYER
	LineSpacing = 1.000000;
	ColorBackground[] = {0,0,0,0};
	ColorText[] = {1,1,1,1};
	font = "CourierNewb64";
	SizeEx = 0.030000;

		};
	class RscGroupBox101 //(#######PART1 OF HEALTHBAR  (JUST LINE)
	type = 0;
	IDC = -1;
	style = 0;
	x = 0.397000;
	y = 0.039000;
	w = 0.001;
	h = 0.027;
	text = "";
	ColorBackground[] = {0,0,0,0.5};
	ColorText[] = {0,0,0,0};
	font = "tahomaB24";
	SizeEx = 0.020000;
		};
class RscGroupBox102 //(#######PART2 OF HEALTHBAR (JUST LINE)
{
	type = 0;
	IDC = -1;
	style = 0;
	x = 0.497000;
	y = 0.039000;
	w = 0.001;
	h = 0.027;
	text = "";
	ColorBackground[] = {0,0,0,0.5};
	ColorText[] = {0,0,0,0};
	font = "tahomaB24";
	SizeEx = 0.020000;
		};
class RscGroupBox103 //(#######PART3 OF HEALTHBAR (JUST LINE)
{
	type = 0;
	IDC = -1;
	style = 0;
	x = 0.597000;
	y = 0.039000;
	w = 0.001;
	h = 0.027;
	text = "";
	ColorBackground[] = {0,0,0,0.5};
	ColorText[] = {0,0,0,0};
	font = "tahomaB24";
	SizeEx = 0.020000;
		};

	};
	
};