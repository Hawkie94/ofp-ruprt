Skript Natankuj
19. okt�ber 2003

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Autor: Bobor SK
Ve�kos� uk�kovej misie: 4,56 kb
Ostrov: Desert Island
Kontakt: boborsk.ofp@inmail.sk
Potrebn� addony: �iadne
Potrebn� verzia hry: 1.75
Tento skript som ale robil vo verzi� 1.91, tak�e nie som si presne ist�...

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Skript je vo viacer�ch s�boroch, aj ke� by sa to s�ce dalo aj jednoduch�ie, ale to sa mi u� nechcelo. Ka�dop�dne to funguje tak, ako m�.

Svoje n�pady a n�vrhu posielajte pros�m na boborsk.ofp@inmail.sk

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
V tomto skripte ide o to, aby ste natankovali lietadlo po�as letu. Je to len uk�kov� misia, preto nevyvalujte o�i, ke� zist�te, �e cisternou je A10 :-)

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Copyright (C) 2003 Bobor SK
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Prajem pr�jemn� z�bavu!