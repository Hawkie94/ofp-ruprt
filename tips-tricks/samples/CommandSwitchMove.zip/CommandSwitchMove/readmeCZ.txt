=================================================================================
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Operation Flashpoin <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

***************************  Uk�zka pohyb� SwitchMove  **************************
=================================================================================


==================================
AUTOR: Didymos *OFP CZ SQUAD* 
       - Didymos@seznam.cz
       - ICQ 120167974
       - www.Didymos.tk
       - www.koflex.cz/ruprt
===================================
VELIKOST: 180�kB
===================================
TYP MISE: uk�zka
===================================
N�ZEV MISE: SwitchMove 
=======================================================================================
POU�IT� ADDONY: ��dn�
=======================================================================================
PO�ADAVKY: Tvo�eno ve verzi 1.91.
           Specifikace m�ho PC:AMD Athlon XP 1600 MHz,256MB DD RAM,GeForce3 Ti 200 64MB
=======================================================================================
INSTALACE: Slo�ku "CommandSwitchMove.Intro" vlo�te do slo�ky missions ve va�em OFP. 
Standartn�: "C:\Program Files\Codemasters\OperationFlashpoint\Missions\.."
nebo:"C:\Program Files\Codemasters\OperationFlashpoint\Users\jm�no\missions\.."                 
=======================================================================================

     Jen mrtv� za�ili konec v�lky. 


 *****       **    *****      *    *    *         *     ***      **
 **    *     **    **    *     *  *     **       **    *   *   *    *
 **     *    **    **     *     **      ***     ***    *   *    *
 **     *    **    **     *     **      ** *   * **    *   *      * 
 **    *     **    **    *      **      **  * *  **    *   *   *    * 
 *****       **    *****        **      **   *   **     ***      **


                                                                  �2003 Didymos


