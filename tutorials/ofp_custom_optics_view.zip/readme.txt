File Pack for Creating Custom Optics in OFP
Created by Earl - earl@baconbomb.com
Dec 20 2002

This file pack is intended for use with my scope view tutorial:
http://www.baconbomb.com/modworks/ofp_custom_optics.html


Contents:
---------
scope_flash.paa - muzzle flash texture as seen from the scope view, taken from FILO M24
demo_scope.paa - scope view texture I created in the tutorial
demo_scope.p3d - scope view model, opens with Oxygen Light, taken from FILO M24*
demo_scope.psd - Photoshop image format, includes all layers used to create scope texture.
screenshot.jpg - OFP screenshot, used as a layer in demo_scope.psd to simulate ingame view.

*Original demo_scope.p3d filename was optika_mildot.p3d, taken from HuBBa and Skaven's FILO M24 Addon.